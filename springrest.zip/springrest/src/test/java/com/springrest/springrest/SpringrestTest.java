package com.springrest.springrest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;


public class SpringrestTest {
String message = "Springrest is the intended message";

@Test
public void testMessage() {
System.out. println("Inside testMessage()");
assertEquals(message, "Springrest is the intended message");
}
}