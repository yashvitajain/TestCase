package com.springrest.springrest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.springrest.springrest.dao.BookDao;
import com.springrest.springrest.entities.Book;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class SpringrestApplicationTests {

	@Autowired
	BookDao bDao;

	//Creating the record
	@Test
	@Order(1)
	public void testCreate() {
		Book b=new Book();
		b.setId(2);
		b.setTitle("Richiiiiiiiiii");
		b.setAuthor("Bala Ramanyam");
		b.setIsbn(24.3f);
		b.setPublishedDate(2);
		b.setGenre("Motivational");
		bDao.save(b);
		assertNotNull(bDao.findById((long) 2).get());
	}

	//ReadingAll the records
	@Test
	@Order(2)
	public void testReadAll() {
		List<Book> list = bDao.findAll();
		assertThat(list).size().isGreaterThan(0);
	}

	//Reading a single record
	@Test
	@Order(3)
	public void testSingleBook() {
		Book b = bDao.findById((long)2).get();
		assertEquals(24.3f,b.getIsbn());
	}

	@Test
	@Order(4)
	public void testUpdate() {
		Book bu= bDao.findById((long) 2).get();
		bu.setIsbn(32.4f);
		bDao.save(bu);
		assertNotEquals(24, bDao.findById((long) 2).get().getIsbn());
	}

	@Test
	@Order(5)
	public void testDelete() {
		bDao.deleteById((long) 2);
		assertThat(bDao.existsById((long) 2)).isFalse();
	}

}
