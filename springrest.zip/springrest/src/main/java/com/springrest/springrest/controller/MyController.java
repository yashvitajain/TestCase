package com.springrest.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springrest.springrest.entities.Book;
import com.springrest.springrest.services.BookService;


@RestController
public class MyController {
	@Autowired
	//var declaration of interface type
	private BookService bookService;
	
	
	@GetMapping("/home")
	public String home() {
		return "Welcome to Book App";
	}
	
	//get the books
	@GetMapping("/books")
	public List<Book> getbooks()
	{
		return this.bookService.getBooks();
	}
	
	@GetMapping("/books/{bookId}")
	//to receive the value @pathvar is used
	public Book getBook(@PathVariable String bookId)
	{
		return this.bookService.getBook(Long.parseLong(bookId));
	}

	@PostMapping("/books")
	public Book addbook(@RequestBody Book book) {
		return this.bookService.addBook(book);
	}
	
	@PutMapping("/books")
	public Book updatebook(@RequestBody Book book) {
		return this.bookService.updateBook(book);
	}
	
	@DeleteMapping("books/{bookId}")
	public ResponseEntity<HttpStatus> deletebook(@PathVariable String bookId){
		try
		{
			this.bookService.deleteBook(Long.parseLong(bookId));
			return new ResponseEntity<>(HttpStatus.OK);
				}catch (Exception e) {
					return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
				}
	}

	
	}

